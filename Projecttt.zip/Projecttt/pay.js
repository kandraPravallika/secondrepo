document.getElementById("paymentForm").addEventListener("submit", function(event) {
    event.preventDefault();
    processPayment();
  });
  
  
  function processPayment() {
    var paymentOption = document.getElementById("paymentOption").value;
    var checkboxes = document.querySelectorAll('input[name="item"]');
    var sum = 0; 
   checkboxes.forEach(function (checkbox) {
   checkbox.addEventListener("change", function () {
    if (this.checked) {
      sum += parseInt(this.value);
    } else {
      sum -= parseInt(this.value);
    }
    
  });
});

    var totalPrice = calculateTotalPrice();
    var paymentMessage = "Payment successful! Amount: Rs" + totalPrice.toFixed(2) + "<br>";
    paymentMessage += "Payment option: " + paymentOption;
  
    document.getElementById("paymentResult").innerHTML = paymentMessage;
  }
  
  function calculateTotalPrice() {
    
      var snacksTotal = 0;
      var checkboxes = document.getElementsByName("item");
    
      checkboxes.forEach(function(checkbox) {
        if (checkbox.checked) {
          snacksTotal += parseInt(checkbox.value);
        }
      });
    var ticketPrice = Number(sessionStorage.getItem("selectedSeatsCount"))*Number(sessionStorage.getItem("price"));
    var totalPrice = snacksTotal + ticketPrice;

  
    return totalPrice;
  }
  function home(){
    setTimeout(function() {
      window.location.href="loginsuccess.html";
    }, 10000);
    

  }